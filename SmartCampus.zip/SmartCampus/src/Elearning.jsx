import { Link } from "react-router-dom";

function Elearning() {
  return (
    <app class="app">
      <h1>Elearning</h1>
      {/* Kod e learningu */}
    </app>
  );
}

export default Elearning;
