import { Link } from "react-router-dom";

function App() {
  return (
    <app class="app">
      <h1>Panel</h1>
    </app>
  );
}

export default App;
