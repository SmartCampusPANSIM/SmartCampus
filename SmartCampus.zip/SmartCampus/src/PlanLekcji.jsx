import { Link } from "react-router-dom";

function PlanLekcji() {
  return (
    <app class="app">
      <h1>Plan lekcji</h1>
      {/* Kod planu leckji */}
    </app>
  );
}

export default PlanLekcji;
